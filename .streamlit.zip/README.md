# WeatherHub - Modern Weather Forecast Application

A beautiful, responsive weather forecasting application built with **Streamlit** and featuring glassmorphism design, interactive charts, and real-time weather data.

## Features ✨

- **Glassmorphism Design**: Modern frosted glass effect with backdrop blur
- **Responsive Sidebar**: Navigation icons and settings
- **Current Weather Card**: Shows temperature, condition, humidity, and wind speed
- **4-Day Forecast**: Beautiful forecast cards with weather conditions
- **Dashboard Widgets**:
  - Daily temperature report chart
  - UV Index circular progress gauge
  - Sunrise/Sunset times
- **Detailed Metrics**: Pressure, visibility, dew point, wind gust
- **Weekly Temperature Trend**: Canvas-based line chart visualization
- **Interactive Weather Map**: Global weather overview with location overlay points
- **Multiple Pages**: Dashboard, Location, Analytics, Settings, About

## Technology Stack

- **Frontend**: Streamlit + Custom CSS
- **Data Visualization**: Plotly
- **Maps**: Folium / Mapbox
- **Data Processing**: Pandas, NumPy
- **Language**: Python 3.8+

## Installation

### Prerequisites
- Python 3.8 or higher
- pip or conda

### Setup Steps

1. **Navigate to project directory**:
   ```powershell
   cd c:\Users\prans\sem1_projectai
   ```

2. **Create a virtual environment** (recommended):
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate.ps1
   ```

3. **Install dependencies**:
   ```powershell
   pip install -r requirements.txt
   ```

## Running the Application

```powershell
streamlit run app.py
```

The app will open in your default browser at `http://localhost:8501`

## Project Structure

```
sem1_projectai/
├── app.py                 # Main application file
├── requirements.txt       # Python dependencies
└── README.md             # This file
```

## Features Breakdown

### 1. **Glassmorphism Design**
- Gradient background (purple to violet)
- Frosted glass cards with backdrop blur
- Semi-transparent borders and shadows
- Responsive mobile-friendly layout

### 2. **Responsive Sidebar Navigation**
- Location selector
- Temperature unit toggle (°C / °F)
- Wind speed unit toggle (km/h / mph)
- 5 main navigation sections

### 3. **Weather Card Component**
- Current temperature and "feels like"
- Weather condition and icon
- Humidity and wind speed display
- 4-day forecast preview

### 4. **Dashboard Widgets**

#### Daily Report Chart
- Hourly temperature visualization
- Smooth line graph with filled area
- Interactive hover details

#### UV Index Gauge
- Circular progress indicator
- Color-coded safety levels
- Real-time UV index value

#### Sunrise/Sunset Widget
- Sunrise and sunset times
- Total daylight hours
- Weather emoji indicators

### 5. **Weekly Temperature Trend**
- Multi-day temperature chart
- High and low temperature visualization
- Filled area between ranges
- Interactive Plotly charts

### 6. **Interactive Weather Map**
- Global weather overview
- Scatter plot with location markers
- Temperature color coding
- Mapbox integration

### 7. **Additional Pages**

**Location Settings**
- Add/manage favorite locations
- Saved locations list

**Weather Analytics**
- Monthly temperature trends
- Rainfall patterns
- Dual-axis chart visualization

**Settings**
- Display preferences
- Unit selection
- Alert notifications

**About**
- App information
- Feature list
- Technology stack

## Customization

### Change Color Scheme
Edit the gradient colors in the CSS section:
```python
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
```

### Add Real Weather Data
Replace the sample data with API calls:
```python
import requests

API_KEY = "your_openweathermap_key"
response = requests.get(
    f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}"
)
current_weather = response.json()
```

### Modify Forecast Data
Edit the `forecast_data` dictionary to pull from a real API

## API Integration (Optional)

To connect to real weather data, you can integrate:

- **OpenWeatherMap API**: https://openweathermap.org/api
- **Weather API**: https://www.weatherapi.com/
- **Tomorrow.io**: https://www.tomorrow.io/

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance Tips

- Use cached data for weather API calls
- Implement lazy loading for charts
- Optimize image assets
- Use Streamlit caching decorators

```python
@st.cache_data
def get_weather_data(city):
    # Fetch weather data
    pass
```

## Troubleshooting

### Charts not displaying
- Check Plotly installation: `pip install --upgrade plotly`
- Clear browser cache

### Sidebar not visible
- Check initial_sidebar_state in set_page_config

### Styling issues
- Ensure CSS is properly escaped in st.markdown()
- Use `unsafe_allow_html=True`

## Future Enhancements

- [ ] Real API integration
- [ ] Historical weather data
- [ ] Weather alerts and notifications
- [ ] User preferences database
- [ ] Dark/Light mode toggle
- [ ] Multi-language support
- [ ] Air quality index
- [ ] Severe weather warnings

## License

MIT License - Feel free to use and modify!

## Author

Created with ❤️ for modern weather forecasting

## Support

For issues or questions, please create an issue in the repository.

---

**Enjoy your beautiful weather application!** 🌤️⛅🌈
